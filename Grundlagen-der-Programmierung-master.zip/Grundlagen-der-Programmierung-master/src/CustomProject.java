import gmbh.kdb.hsw.gdp.domain.*;

public class CustomProject extends Project {

    public CustomProject(ProjectName name, Skillset effort, Money reward, CompanyName customer, Day deadline) {
        super(name, effort, reward, customer, deadline);
    }

}
