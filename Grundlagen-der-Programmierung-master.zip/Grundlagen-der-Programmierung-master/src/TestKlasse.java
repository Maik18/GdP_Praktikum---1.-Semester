
//Testet hier ob die klassen funktionieren(nicht direkt relevant für die aufgabe)
public class TestKlasse {
    public static void main(String args[])
    {
        CaeserChiffre chiff = new CaeserChiffre();
        chiff.verschluesseln();
    }
}
